package cn.com.ccxi.test;

public class One {
	public String name = "12";
}
