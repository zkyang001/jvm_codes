package cn.com.ccxi.test;

public class ABSImplDemo extends TestOq1{

	public ABSImplDemo(String one) {
		super(one);
		// TODO Auto-generated constructor stub
	}



}
