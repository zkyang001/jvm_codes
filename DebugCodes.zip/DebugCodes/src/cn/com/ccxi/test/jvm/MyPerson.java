package cn.com.ccxi.test.jvm;

public class MyPerson {
    
    private MyPerson myPerson;
    
    public void setMyPerson(Object myPerson) {
        this.myPerson = (MyPerson)myPerson;
    }

}
